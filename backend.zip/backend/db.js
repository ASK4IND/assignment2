const mysql = require('mysql2');
const db = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root@2004',
    database:'prac',
});
db.connect(err=>{
    if (err) throw err ;
    console.log("MY sql is connected")
})

module.exports = db ;



// create database prac;
// use prac;
// create table inf(
// Id Int ,
// Name varchar(30),
// college varchar(30)
// );


// insert into inf values(1,"Abhay","wce");

// select * from inf;
