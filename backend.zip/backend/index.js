// const express = require('express')
// const cors = require('cors')
// const db = require('./db.js')
// const app = express();
// app.use(cors());
// app.use(express.json());


// app.get('/',(req,res)=>{
//     db.query('Select * from inf ;',(err,results)=>{
//         if (err) return res.status(500).json({error:err.message});
//         res.json(results);
//     })
// })

// // create table info(id Int primary key,name varchar(30),college varchar(30));

// app.post('/add',(req,res)=>{
// const{id,Name,College}=req.body ;
// console.log('hello');
// // db.query("insert into inf (Id , name, college) values (?, ?, ?)",[Id,Name,college],(err,results)=>{
// //     if (err) return res.status(500).json({error:err.message});
// //     res.json("success")
// // });
// })





// const PORT = 3000 ;
// app.listen(PORT , ()=>{
//     console.log("Server runing on 3000")
// })













const express = require("express");
const cors = require('cors')
const app = express();
const db = require('./db.js')
app.use(cors()) ;
app.use(express.json());


app.get('/' ,(req,res)=>{
    db.query('Select * from inf ;',
        (err,results)=>{
        if (err) return res.status(500).json({error:err.message});
        res.json(results);
    })
})

// create table inf(
//     Id Int ,
//     Name varchar(30),
//     college varchar(30)
//     );

app.post('/add',(req,res)=>{
    const {Id ,Name,college} = req.body ;
    console.log(req.body);
    db.query('Insert into inf (Id ,Name,college) values(?, ?, ?)',[Id ,Name,college],(err,results)=>{ if(err) return res.status(500).json({error:err.message});
    res.json({message:'Form submitted successfully ...'}) ;
    })
});

const PORT = 4000;
app.listen(PORT, ()=> {
    console.log("server runs on 3000")
});