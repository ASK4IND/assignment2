import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, RESPONSE_INIT } from '@angular/core';
import { FormsModule } from '@angular/forms';



@Component({
  selector: 'app-form',
  imports: [FormsModule,HttpClientModule],
  templateUrl: './form.component.html',
  styleUrl: './form.component.css'
})
export class FormComponent {

  constructor(private http:HttpClient) {}
  model = {Id: 0 , Name:'' , college: ''};
 
  onSubmit(form:any){
    console.log(form.value)
  }

  AddForm(form:any) :void {
    
    console.log(this.model)
   this.http.post('http://localhost:4000/add',this.model)
   .subscribe(
    (response) => {
      this.model = {Id: 0 , Name:'' , college: ''}
    },
    (error) => {
      console.log(error)
    }
   ) }
  }


